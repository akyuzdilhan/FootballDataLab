from dash import html

layout = html.Div([
    html.H3("Welcome to the Football Data Lab Dashboard!"),
    
])