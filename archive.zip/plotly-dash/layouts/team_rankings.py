from dash import html

layout = html.Div([
    html.H3("Team Rankings Content"),
    
])
