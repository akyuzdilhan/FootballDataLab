from dash import html

layout = html.Div([
    html.H3("Player Analysis Content"),
    
])
